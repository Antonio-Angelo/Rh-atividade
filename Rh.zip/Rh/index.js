const fs = require('fs');
const readline = require('readline');
const path = require('path');


const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});


function perguntar(pergunta) {
  return new Promise((resolve) => {
    rl.question(pergunta, (resposta) => resolve(resposta));
  });
}

async function cadastrar() {
  try {
    console.log("\n=== BANCO DE TALENTOS - RH ===");

   
    const nome = await perguntar("Nome completo: ");
    const idade = await perguntar("Idade: ");
    const telefone = await perguntar("Telefone: ");
    const endereco = await perguntar("Endereço: ");
    const profissao = await perguntar("Profissão: ");

   
    const pastaPrincipal = path.join(__dirname, 'Curriculos');

    if (!fs.existsSync(pastaPrincipal)) {
      fs.mkdirSync(pastaPrincipal);
      console.log("✔ Pasta 'Curriculos' criada");
    }

   
    const pastaProf = path.join(pastaPrincipal, profissao);

    if (!fs.existsSync(pastaProf)) {
      fs.mkdirSync(pastaProf);
      console.log(`✔ Pasta da profissão '${profissao}' criada`);
    }

    
    const nomeArquivo = path.join(pastaProf, `${nome.replace(/\s+/g, '_')}.txt`);

    const conteudo = `
Nome: ${nome}
Idade: ${idade}
Telefone: ${telefone}
Endereço: ${endereco}
Profissão: ${profissao}
`;

    fs.writeFileSync(nomeArquivo, conteudo.trim());

    console.log(`✔ Cadastro salvo em: ${nomeArquivo}`);

  } catch (erro) {
    console.error(" Erro ao salvar cadastro:", erro.message);
  }

  const continuar = await perguntar("\nDeseja cadastrar mais alguém? (s/n): ");

  if (continuar.toLowerCase() === 's') {
    await cadastrar();
  } else {
    console.log("\nSistema finalizado. Até a próxima!");
    rl.close();
  }
}

// Iniciar
cadastrar();
